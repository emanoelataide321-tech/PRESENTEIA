# PRESENTEIA — Sistema completo integrado

Pacote integrado com **loja + API + PostgreSQL + painel administrativo**.

## O que foi corrigido

- O checkout agora envia o pedido completo para `POST /api/pedidos`.
- O servidor recalcula os preços usando o banco e valida o estoque.
- O estoque é baixado automaticamente quando o pedido é criado.
- O cliente é criado/atualizado pelo e-mail.
- O pedido recebe número `PTxxxxxx` e código de rastreio.
- O pedido ganha histórico de eventos.
- O painel altera status e registra histórico.
- Cancelamento/reembolso devolve os produtos ao estoque uma única vez.
- O painel permite alterar rastreio, previsão e adicionar observação.
- Busca de pedidos aceita número, cliente, e-mail, telefone e rastreio.
- O site carrega produtos, embalagens, extras e cartões do banco; se a API estiver indisponível, usa o catálogo local como fallback.
- O mesmo servidor pode entregar o site em `/` e o painel em `/admin`.
- Foi adicionado endpoint de frete estimado para o fluxo do checkout.

## Estrutura

```
PRESENTEIA-SISTEMA-COMPLETO/
├── public/
│   ├── index.html              # loja
│   └── admin/index.html        # painel
├── backend/
│   ├── server.js              # API
│   ├── schema.sql              # banco + dados iniciais
│   ├── migrate.js
│   ├── seed-admin.js
│   ├── package.json
│   ├── Dockerfile
│   └── .env.example
├── docker-compose.yml
└── README.md
```

## Rodar localmente com Docker

Requer Docker Desktop.

```bash
docker compose up --build
```

Depois:

- Loja: http://localhost:3000
- Painel: http://localhost:3000/admin
- API: http://localhost:3000/api/health

Login inicial definido no `docker-compose.yml`:

- E-mail: `admin@presenteia.com.br`
- Senha: `troque-esta-senha`

**Troque a senha antes de publicar.**

## Rodar sem Docker

1. Instale Node.js 20+ e PostgreSQL.
2. Entre em `backend/`.
3. Copie `.env.example` para `.env`.
4. Configure `DATABASE_URL`, `JWT_SECRET` e credenciais do administrador.
5. Execute:

```bash
npm install
npm run migrate
npm run seed:admin
npm start
```

O servidor procura `../public` automaticamente.

## Produção / Render

Use PostgreSQL persistente e um Web Service Node. Configure as variáveis do `.env.example` no serviço. O banco deve receber `npm run migrate` uma vez antes do uso.

Se o site e o painel forem publicados separados do backend, defina no início dos dois HTMLs:

```js
window.PRESENTEIA_API_BASE_URL = 'https://SEU-BACKEND.onrender.com';
```

Se estiverem no mesmo serviço, deixe vazio: a API será chamada no mesmo domínio.

## Importante sobre pagamentos e frete

Este pacote deixa o **pedido e o estoque reais no banco**, mas não transforma sozinho Pix/cartão em cobrança financeira real. Para receber pagamentos automaticamente ainda é necessário configurar Mercado Pago (ou outro PSP), webhooks e credenciais no backend. O frete também está como estimativa; uma cotação oficial exige integração com Correios/Melhor Envio e respectivas credenciais.

## Deploy no Render

O projeto inclui `render.yaml`. Ao conectar o repositório ao Render usando Blueprint, ele cria o Web Service e o PostgreSQL e liga `DATABASE_URL` automaticamente.

Variáveis secretas que devem ser informadas no Render:
- `ADMIN_EMAIL`
- `ADMIN_PASSWORD`

`JWT_SECRET` é gerado automaticamente pelo Blueprint.

O serviço executa a migração e cria/atualiza o administrador antes de iniciar o servidor. O site, API e `/admin` ficam no mesmo domínio, então o frontend não precisa de uma URL de backend separada.
