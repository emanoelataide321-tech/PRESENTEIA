require('dotenv').config();
const path = require('path');
const express = require('express');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const { Pool } = require('pg');

if (!process.env.DATABASE_URL) throw new Error('DATABASE_URL não configurada. Crie o .env antes de iniciar.');
if (!process.env.JWT_SECRET) throw new Error('JWT_SECRET não configurado. Crie o .env antes de iniciar.');

const app = express();
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DATABASE_SSL === 'true' ? { rejectUnauthorized: false } : false,
});
const JWT_SECRET = process.env.JWT_SECRET;
const ALLOWED_ORIGINS = (process.env.CORS_ORIGINS || '').split(',').map(s=>s.trim()).filter(Boolean);

app.use(cors({
  origin(origin, cb){
    if(!origin || ALLOWED_ORIGINS.length===0 || ALLOWED_ORIGINS.includes(origin)) return cb(null,true);
    return cb(new Error('Origem não permitida por CORS'));
  }
}));
app.use(express.json({limit:'1mb'}));

const STATUS_VALIDOS=['novo','pago','preparacao','montado','enviado','entregue','cancelado','reembolsado'];
const STATUS_LABEL={novo:'Novo',pago:'Pago',preparacao:'Em preparação',montado:'Montado',enviado:'Enviado',entregue:'Entregue',cancelado:'Cancelado',reembolsado:'Reembolsado'};
function erro(msg,status=400){ return Object.assign(new Error(msg),{status}); }
function asyncRoute(fn){return (req,res)=>Promise.resolve(fn(req,res)).catch(e=>{console.error(e);res.status(e.status||500).json({erro:e.message||'Erro interno no servidor'});});}
function gerarNumeroPedido(){return 'PT'+Math.floor(100000+Math.random()*900000);}
function gerarCodigoRastreio(){const letras='ABCDEFGHIJKLMNOPQRSTUVWXYZ';let s='';for(let i=0;i<2;i++)s+=letras[Math.floor(Math.random()*letras.length)];return s+Math.floor(100000000+Math.random()*900000000)+'BR';}
function authMiddleware(req,res,next){const h=req.headers.authorization||'';const t=h.startsWith('Bearer ')?h.slice(7):null;if(!t)return res.status(401).json({erro:'Token não enviado'});try{req.admin=jwt.verify(t,JWT_SECRET);next();}catch{return res.status(401).json({erro:'Token inválido ou expirado'});}}
function money(v){return Math.round(Number(v||0)*100)/100;}

app.get('/api/health',asyncRoute(async(req,res)=>{await pool.query('SELECT 1');res.json({ok:true,db:true});}));

// ---------------- PUBLIC CATALOG ----------------
app.get('/api/produtos',asyncRoute(async(req,res)=>{const {rows}=await pool.query('SELECT id,name,description,price,categories,emoji,gradient,image_url,rating,stock,active FROM products WHERE active=true ORDER BY name');res.json(rows.map(p=>({id:p.id,name:p.name,cat:p.categories||[],price:Number(p.price),rating:Number(p.rating||4.8),emoji:p.emoji||'',desc:p.description||'',grad:p.gradient||'',image:p.image_url||null,stock:p.stock,esgotado:p.stock<=0})))}));
app.get('/api/embalagens',asyncRoute(async(req,res)=>{const [boxes,colors,ribbons,papers,extras]=await Promise.all([pool.query('SELECT id,name,price,capacity,emoji,stock FROM packaging_boxes WHERE active=true ORDER BY price'),pool.query('SELECT id,hex FROM box_colors WHERE active=true ORDER BY id'),pool.query('SELECT id,label,hex FROM ribbons WHERE active=true ORDER BY id'),pool.query('SELECT id,hex FROM papers WHERE active=true ORDER BY id'),pool.query('SELECT id,emoji,name,price FROM extras WHERE active=true ORDER BY price')]);res.json({packaging:boxes.rows.map(b=>({...b,price:Number(b.price),esgotado:b.stock<=0})),boxColors:colors.rows,ribbons:ribbons.rows,papers:papers.rows,extras:extras.rows.map(e=>({...e,price:Number(e.price)}))});}));
app.get('/api/cartoes',asyncRoute(async(req,res)=>{const [a,b]=await Promise.all([pool.query('SELECT id,emoji,label FROM card_types WHERE active=true ORDER BY id'),pool.query('SELECT id,emoji,name,tags FROM occasions WHERE active=true ORDER BY id')]);res.json({cardTypes:a.rows,occasions:b.rows});}));

// Frete estimado local, para o site continuar integrado sem depender de credenciais externas.
const UF_DIST={SP:0,RJ:1,MG:1,ES:1,PR:1,SC:2,RS:2,DF:2,GO:2,MT:2,MS:2,BA:3,SE:3,AL:3,PE:3,PB:3,RN:3,CE:3,PI:3,MA:3,TO:3,PA:4,AM:4,AC:4,RO:4,RR:4,AP:4};
app.post('/api/frete/calcular',asyncRoute(async(req,res)=>{const cep=String(req.body?.cepDestino||'').replace(/\D/g,'');if(cep.length!==8)throw erro('CEP inválido');let uf=null;try{const r=await fetch('https://viacep.com.br/ws/'+cep+'/json/');const d=await r.json();if(!d.erro)uf=d.uf;}catch{}const dist=uf?(UF_DIST[uf]??3):3;res.json({opcoes:[{transportadora:'Correios',servico:'PAC',valor:money(14.9+dist*9),prazoDias:Math.min(3+dist*2,12)},{transportadora:'Correios',servico:'SEDEX',valor:money(24.9+dist*14),prazoDias:Math.min(1+dist,6)}]});}));

// ---------------- ORDERS ----------------
app.post('/api/pedidos',asyncRoute(async(req,res)=>{
  const {gifts,cliente,entrega,pagamento,frete}=req.body||{};
  if(!Array.isArray(gifts)||!gifts.length)throw erro('Pedido sem presentes');
  if(!cliente?.nome||!cliente?.email)throw erro('Nome e e-mail são obrigatórios');
  const client=await pool.connect();
  try{
    await client.query('BEGIN');
    let subtotal=0;const flat=[];
    for(let gi=0;gi<gifts.length;gi++){
      const g=gifts[gi]||{};
      if(!Array.isArray(g.items)||!g.items.length)throw erro('O presente #'+(gi+1)+' não possui produtos');
      for(const item of g.items){const qty=Number(item.qty);if(!Number.isInteger(qty)||qty<1)throw erro('Quantidade inválida');const r=await client.query('SELECT id,name,price,stock,active FROM products WHERE id=$1 FOR UPDATE',[item.id]);const p=r.rows[0];if(!p||!p.active)throw erro('Produto indisponível: '+item.id,409);if(p.stock<qty)throw erro(`Estoque insuficiente para "${p.name}" (disponível: ${p.stock})`,409);const unit=Number(p.price),line=money(unit*qty);subtotal+=line;flat.push({gift_index:gi,product_id:p.id,product_name:p.name,quantity:qty,unit_price:unit,line_total:line});}
      if(g.packaging){const r=await client.query('SELECT price FROM packaging_boxes WHERE id=$1 AND active=true',[g.packaging]);if(r.rows[0])subtotal+=Number(r.rows[0].price);}
      for(const id of (g.extras||[])){const r=await client.query('SELECT price FROM extras WHERE id=$1 AND active=true',[id]);if(r.rows[0])subtotal+=Number(r.rows[0].price);}
    }
    const shipping=money(frete?.valor||0), total=money(subtotal+shipping);
    const email=String(cliente.email).trim().toLowerCase();let customerId=null;let r=await client.query('SELECT id FROM customers WHERE email=$1',[email]);
    if(r.rows[0]){customerId=r.rows[0].id;await client.query('UPDATE customers SET name=$1,phone=COALESCE($2,phone) WHERE id=$3',[cliente.nome,cliente.telefone||null,customerId]);}
    else{r=await client.query('INSERT INTO customers(name,email,phone) VALUES($1,$2,$3) RETURNING id',[cliente.nome,email,cliente.telefone||null]);customerId=r.rows[0].id;}
    let orderNumber;for(let i=0;i<10;i++){orderNumber=gerarNumeroPedido();const x=await client.query('SELECT 1 FROM orders WHERE order_number=$1',[orderNumber]);if(!x.rows.length)break;}
    let trackingCode;for(let i=0;i<10;i++){trackingCode=gerarCodigoRastreio();const x=await client.query('SELECT 1 FROM orders WHERE tracking_code=$1',[trackingCode]);if(!x.rows.length)break;}
    const prazo=Number(frete?.prazo||5);const eta=new Date();eta.setDate(eta.getDate()+prazo);
    r=await client.query(`INSERT INTO orders(order_number,customer_id,customer_name,customer_email,customer_phone,shipping_address,delivery_method,carrier,service,tracking_code,estimated_delivery,payment_method,payment_status,subtotal,shipping,discount,total,status,gifts) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,'pendente',$13,$14,0,$15,'novo',$16) RETURNING id,order_number,tracking_code,estimated_delivery,total`,[orderNumber,customerId,cliente.nome,email,cliente.telefone||null,JSON.stringify({...entrega,cpf:cliente.cpf||null}),entrega?.tipo||'normal',frete?.transportadora||'Correios',frete?.servico||'PAC',trackingCode,eta,pagamento?.metodo||null,subtotal,shipping,total,JSON.stringify(gifts)]);
    const order=r.rows[0];
    for(const it of flat){await client.query('INSERT INTO order_items(order_id,gift_index,product_id,product_name,quantity,unit_price,line_total) VALUES($1,$2,$3,$4,$5,$6,$7)',[order.id,it.gift_index,it.product_id,it.product_name,it.quantity,it.unit_price,it.line_total]);const u=await client.query('UPDATE products SET stock=stock-$1,updated_at=now() WHERE id=$2 RETURNING stock',[it.quantity,it.product_id]);await client.query('INSERT INTO stock_movements(product_id,change,reason,resulting_stock,order_id) VALUES($1,$2,$3,$4,$5)',[it.product_id,-it.quantity,'Venda — pedido '+orderNumber,u.rows[0].stock,order.id]);}
    await client.query('INSERT INTO order_events(order_id,status,note,created_by) VALUES($1,$2,$3,NULL)',[order.id,'novo','Pedido criado pelo site']);
    await client.query('COMMIT');res.status(201).json({id:order.id,number:order.order_number,trackingCode:order.tracking_code,total:Number(order.total),eta:new Date(order.estimated_delivery).toLocaleDateString('pt-BR',{day:'2-digit',month:'long'})});
  }catch(e){await client.query('ROLLBACK');throw e;}finally{client.release();}
}));

app.get('/api/pedidos/rastreio/:codigo',asyncRoute(async(req,res)=>{const r=await pool.query(`SELECT order_number,status,carrier,service,tracking_code,estimated_delivery,created_at,updated_at FROM orders WHERE tracking_code=$1`,[String(req.params.codigo).toUpperCase()]);if(!r.rows[0])throw erro('Código de rastreio não encontrado',404);const ev=await pool.query('SELECT status,note,created_at FROM order_events WHERE order_id=(SELECT id FROM orders WHERE tracking_code=$1) ORDER BY created_at',[String(req.params.codigo).toUpperCase()]);res.json({...r.rows[0],events:ev.rows});}));

// ---------------- ADMIN ----------------
app.post('/api/admin/login',asyncRoute(async(req,res)=>{const email=String(req.body?.email||'').toLowerCase(),senha=req.body?.senha;if(!email||!senha)throw erro('Informe e-mail e senha');const r=await pool.query('SELECT * FROM admin_users WHERE email=$1',[email]);const a=r.rows[0];if(!a||!(await bcrypt.compare(senha,a.password_hash)))throw erro('Credenciais inválidas',401);const token=jwt.sign({id:a.id,email:a.email,name:a.name},JWT_SECRET,{expiresIn:'12h'});res.json({token,admin:{id:a.id,email:a.email,name:a.name}});}));
app.use('/api/admin',authMiddleware);
app.get('/api/admin/me',asyncRoute(async(req,res)=>res.json({admin:req.admin})));
app.get('/api/admin/dashboard',asyncRoute(async(req,res)=>{const q=(sql,p=[])=>pool.query(sql,p).then(x=>x.rows[0]);const [hoje,mes,sc,baixo,esg]=await Promise.all([q(`SELECT COUNT(*)::int pedidos,COALESCE(SUM(total),0)::float vendas FROM orders WHERE created_at::date=CURRENT_DATE AND status NOT IN('cancelado','reembolsado')`),q(`SELECT COALESCE(SUM(total),0)::float vendas FROM orders WHERE date_trunc('month',created_at)=date_trunc('month',CURRENT_DATE) AND status NOT IN('cancelado','reembolsado')`),pool.query('SELECT status,COUNT(*)::int total FROM orders GROUP BY status').then(x=>x.rows),q('SELECT COUNT(*)::int total FROM products WHERE active AND stock>0 AND stock<=min_stock'),q('SELECT COUNT(*)::int total FROM products WHERE active AND stock<=0')]);const ps=Object.fromEntries(STATUS_VALIDOS.map(s=>[s,0]));sc.forEach(x=>ps[x.status]=x.total);res.json({pedidosHoje:hoje.pedidos,vendasHoje:hoje.vendas,vendasMes:mes.vendas,aguardandoPreparacao:ps.pago+ps.preparacao,enviados:ps.enviado,entregues:ps.entregue,produtosEstoqueBaixo:baixo.total,produtosEsgotados:esg.total,pedidosPorStatus:ps});}));
app.get('/api/admin/pedidos',asyncRoute(async(req,res)=>{const {status,busca}=req.query;const c=[],p=[];if(status){p.push(status);c.push(`status=$${p.length}`);}if(busca){p.push('%'+busca+'%');c.push(`(order_number ILIKE $${p.length} OR customer_name ILIKE $${p.length} OR customer_email ILIKE $${p.length} OR customer_phone ILIKE $${p.length} OR tracking_code ILIKE $${p.length})`);}const where=c.length?'WHERE '+c.join(' AND '):'';const r=await pool.query(`SELECT id,order_number,customer_name,customer_email,customer_phone,total,status,payment_method,payment_status,tracking_code,estimated_delivery,created_at FROM orders ${where} ORDER BY created_at DESC LIMIT 300`,p);res.json(r.rows.map(x=>({...x,total:Number(x.total)})));}));
app.get('/api/admin/pedidos/:id',asyncRoute(async(req,res)=>{const r=await pool.query('SELECT * FROM orders WHERE id=$1',[req.params.id]);if(!r.rows[0])throw erro('Pedido não encontrado',404);const [items,events]=await Promise.all([pool.query('SELECT * FROM order_items WHERE order_id=$1 ORDER BY gift_index,id',[req.params.id]),pool.query('SELECT * FROM order_events WHERE order_id=$1 ORDER BY created_at',[req.params.id])]);const p=r.rows[0];res.json({...p,total:Number(p.total),subtotal:Number(p.subtotal),shipping:Number(p.shipping),discount:Number(p.discount),gifts:typeof p.gifts==='string'?JSON.parse(p.gifts):p.gifts,shipping_address:typeof p.shipping_address==='string'?JSON.parse(p.shipping_address):p.shipping_address,order_items:items.rows,events:events.rows});}));
app.patch('/api/admin/pedidos/:id/status',asyncRoute(async(req,res)=>{const status=req.body?.status;if(!STATUS_VALIDOS.includes(status))throw erro('Status inválido');const client=await pool.connect();try{await client.query('BEGIN');const old=(await client.query('SELECT * FROM orders WHERE id=$1 FOR UPDATE',[req.params.id])).rows[0];if(!old)throw erro('Pedido não encontrado',404);if(old.status===status){await client.query('COMMIT');return res.json(old);}if(['cancelado','reembolsado'].includes(status)&&!['cancelado','reembolsado'].includes(old.status)){const items=await client.query('SELECT product_id,quantity FROM order_items WHERE order_id=$1 AND product_id IS NOT NULL',[old.id]);for(const it of items.rows){const u=await client.query('UPDATE products SET stock=stock+$1,updated_at=now() WHERE id=$2 RETURNING stock',[it.quantity,it.product_id]);await client.query('INSERT INTO stock_movements(product_id,change,reason,resulting_stock,order_id,created_by) VALUES($1,$2,$3,$4,$5,$6)',[it.product_id,it.quantity,'Estorno por '+STATUS_LABEL[status]+' — pedido '+old.order_number,u.rows[0].stock,old.id,req.admin.id]);}}
const payment=['pago','preparacao','montado','enviado','entregue'].includes(status)?'pago':status==='novo'?'pendente':old.payment_status;const r=await client.query('UPDATE orders SET status=$1,payment_status=$2,updated_at=now() WHERE id=$3 RETURNING *',[status,payment,old.id]);await client.query('INSERT INTO order_events(order_id,status,note,created_by) VALUES($1,$2,$3,$4)',[old.id,status,'Status alterado no painel para '+STATUS_LABEL[status],req.admin.id]);await client.query('COMMIT');res.json(r.rows[0]);}catch(e){await client.query('ROLLBACK');throw e;}finally{client.release();}}));
app.patch('/api/admin/pedidos/:id/detalhes',asyncRoute(async(req,res)=>{const {tracking_code,estimated_delivery,note}=req.body||{};const r=await pool.query('UPDATE orders SET tracking_code=COALESCE($1,tracking_code),estimated_delivery=COALESCE($2,estimated_delivery),updated_at=now() WHERE id=$3 RETURNING *',[tracking_code||null,estimated_delivery||null,req.params.id]);if(!r.rows[0])throw erro('Pedido não encontrado',404);if(note)await pool.query('INSERT INTO order_events(order_id,status,note,created_by) VALUES($1,$2,$3,$4)',[req.params.id,r.rows[0].status,note,req.admin.id]);res.json(r.rows[0]);}));

// Products/stock
app.get('/api/admin/produtos',asyncRoute(async(req,res)=>res.json((await pool.query('SELECT * FROM products ORDER BY name')).rows)));
app.post('/api/admin/produtos',asyncRoute(async(req,res)=>{const b=req.body||{};if(!b.id||!b.name||Number(b.price)<0)throw erro('ID, nome e preço são obrigatórios');const r=await pool.query(`INSERT INTO products(id,name,description,price,categories,emoji,gradient,image_url,stock,min_stock,active) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING *`,[b.id,b.name,b.description||'',Number(b.price),b.categories||[],b.emoji||'',b.gradient||'',b.image_url||null,Number(b.stock||0),Number(b.min_stock??3),b.active!==false]);res.status(201).json(r.rows[0]);}));
app.put('/api/admin/produtos/:id',asyncRoute(async(req,res)=>{const b=req.body||{};const r=await pool.query(`UPDATE products SET name=$1,description=$2,price=$3,categories=$4,emoji=$5,gradient=$6,image_url=$7,active=$8,updated_at=now() WHERE id=$9 RETURNING *`,[b.name,b.description||'',Number(b.price),b.categories||[],b.emoji||'',b.gradient||'',b.image_url||null,b.active!==false,req.params.id]);if(!r.rows[0])throw erro('Produto não encontrado',404);res.json(r.rows[0]);}));
app.patch('/api/admin/produtos/:id/estoque',asyncRoute(async(req,res)=>{const {tipo,quantidade,motivo}=req.body||{},q=Number(quantidade);if(!Number.isFinite(q)||q<0)throw erro('Quantidade inválida');const c=await pool.connect();try{await c.query('BEGIN');const r=await c.query('SELECT stock FROM products WHERE id=$1 FOR UPDATE',[req.params.id]);if(!r.rows[0])throw erro('Produto não encontrado',404);const old=r.rows[0].stock;let novo=tipo==='add'?old+q:tipo==='remove'?Math.max(0,old-q):tipo==='set'?q:null;if(novo===null)throw erro('Tipo inválido');const u=await c.query('UPDATE products SET stock=$1,updated_at=now() WHERE id=$2 RETURNING *',[novo,req.params.id]);await c.query('INSERT INTO stock_movements(product_id,change,reason,resulting_stock,created_by) VALUES($1,$2,$3,$4,$5)',[req.params.id,novo-old,motivo||'Ajuste manual: '+tipo,novo,req.admin.id]);await c.query('COMMIT');res.json(u.rows[0]);}catch(e){await c.query('ROLLBACK');throw e;}finally{c.release();}}));
app.patch('/api/admin/produtos/:id/min-estoque',asyncRoute(async(req,res)=>{const r=await pool.query('UPDATE products SET min_stock=$1 WHERE id=$2 RETURNING *',[Number(req.body?.min_stock),req.params.id]);if(!r.rows[0])throw erro('Produto não encontrado',404);res.json(r.rows[0]);}));

function crud(tabela,campos){const cols=campos.join(',');app.get('/api/admin/'+tabela,asyncRoute(async(req,res)=>res.json((await pool.query(`SELECT * FROM ${tabela} ORDER BY id`)).rows)));app.post('/api/admin/'+tabela,asyncRoute(async(req,res)=>{const vals=campos.map(c=>req.body[c]);const r=await pool.query(`INSERT INTO ${tabela}(${cols}) VALUES(${campos.map((_,i)=>'$'+(i+1)).join(',')}) RETURNING *`,vals);res.status(201).json(r.rows[0]);}));app.put('/api/admin/'+tabela+'/:id',asyncRoute(async(req,res)=>{const c2=campos.filter(c=>c!=='id'),vals=c2.map(c=>req.body[c]);vals.push(req.params.id);const r=await pool.query(`UPDATE ${tabela} SET ${c2.map((c,i)=>c+'=$'+(i+1)).join(',')} WHERE id=$${vals.length} RETURNING *`,vals);if(!r.rows[0])throw erro('Não encontrado',404);res.json(r.rows[0]);}));app.patch('/api/admin/'+tabela+'/:id/ativo',asyncRoute(async(req,res)=>{const r=await pool.query(`UPDATE ${tabela} SET active=$1 WHERE id=$2 RETURNING *`,[!!req.body.active,req.params.id]);if(!r.rows[0])throw erro('Não encontrado',404);res.json(r.rows[0]);}));}
crud('packaging_boxes',['id','name','price','capacity','emoji','stock','min_stock','active']);crud('ribbons',['id','label','hex','active']);crud('papers',['id','hex','active']);crud('box_colors',['id','hex','active']);crud('extras',['id','emoji','name','price','active']);crud('card_types',['id','emoji','label','category','active']);crud('occasions',['id','emoji','name','tags','active']);
app.get('/api/admin/clientes',asyncRoute(async(req,res)=>{const r=await pool.query(`SELECT c.id,c.name,c.email,c.phone,COUNT(o.id)::int numero_pedidos,COALESCE(SUM(o.total) FILTER(WHERE o.status NOT IN('cancelado','reembolsado')),0)::float total_gasto,MAX(o.created_at) ultimo_pedido FROM customers c LEFT JOIN orders o ON o.customer_id=c.id GROUP BY c.id ORDER BY ultimo_pedido DESC NULLS LAST`);res.json(r.rows);}));

// Serve site + admin from one deployment when public/ exists.
const publicDir=path.join(__dirname,'..','public');
app.use(express.static(publicDir));
app.get('/admin',(req,res)=>res.sendFile(path.join(publicDir,'admin','index.html')));
app.get('*',(req,res,next)=>{if(req.path.startsWith('/api/'))return next();res.sendFile(path.join(publicDir,'index.html'));});

const PORT=process.env.PORT||3000;app.listen(PORT,()=>console.log(`Presenteia backend rodando na porta ${PORT}`));
