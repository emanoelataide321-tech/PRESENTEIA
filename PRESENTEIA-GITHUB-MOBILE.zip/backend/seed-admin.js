// Cria (ou atualiza a senha de) o usuário administrador definido nas variáveis
// ADMIN_EMAIL / ADMIN_PASSWORD / ADMIN_NAME do arquivo .env
// Uso: npm run seed:admin
require('dotenv').config();
const bcrypt = require('bcryptjs');
const { Pool } = require('pg');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DATABASE_SSL === 'true' ? { rejectUnauthorized: false } : false,
});

async function main() {
  const email = process.env.ADMIN_EMAIL;
  const password = process.env.ADMIN_PASSWORD;
  const name = process.env.ADMIN_NAME || 'Administrador';
  if (!email || !password) {
    console.error('Defina ADMIN_EMAIL e ADMIN_PASSWORD no arquivo .env antes de rodar este script.');
    process.exit(1);
  }
  const hash = await bcrypt.hash(password, 10);
  await pool.query(
    `INSERT INTO admin_users (email, password_hash, name)
     VALUES ($1,$2,$3)
     ON CONFLICT (email) DO UPDATE SET password_hash = EXCLUDED.password_hash, name = EXCLUDED.name`,
    [email.toLowerCase(), hash, name]
  );
  console.log(`Usuário administrador pronto: ${email}`);
  await pool.end();
}

main().catch((err) => {
  console.error('Erro ao criar administrador:', err);
  process.exit(1);
});
