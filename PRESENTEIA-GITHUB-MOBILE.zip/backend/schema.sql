-- =====================================================================
-- PRESENTEIA — schema do banco de dados compartilhado (site + painel)
-- Rode este arquivo uma vez no seu banco Postgres (ex: via "npm run migrate")
-- =====================================================================

CREATE TABLE IF NOT EXISTS admin_users (
  id SERIAL PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  name TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS products (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  price NUMERIC(10,2) NOT NULL,
  categories TEXT[] NOT NULL DEFAULT '{}',
  emoji TEXT DEFAULT '',
  gradient TEXT DEFAULT '',
  image_url TEXT,
  rating NUMERIC(2,1) DEFAULT 4.8,
  stock INTEGER NOT NULL DEFAULT 0,
  min_stock INTEGER NOT NULL DEFAULT 3,
  active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS packaging_boxes (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  price NUMERIC(10,2) NOT NULL,
  capacity INTEGER NOT NULL,
  emoji TEXT DEFAULT '',
  stock INTEGER NOT NULL DEFAULT 0,
  min_stock INTEGER NOT NULL DEFAULT 3,
  active BOOLEAN NOT NULL DEFAULT true
);

CREATE TABLE IF NOT EXISTS box_colors (
  id TEXT PRIMARY KEY,
  hex TEXT NOT NULL,
  active BOOLEAN NOT NULL DEFAULT true
);

CREATE TABLE IF NOT EXISTS ribbons (
  id TEXT PRIMARY KEY,
  label TEXT,
  hex TEXT NOT NULL,
  active BOOLEAN NOT NULL DEFAULT true
);

CREATE TABLE IF NOT EXISTS papers (
  id TEXT PRIMARY KEY,
  hex TEXT NOT NULL,
  active BOOLEAN NOT NULL DEFAULT true
);

CREATE TABLE IF NOT EXISTS extras (
  id TEXT PRIMARY KEY,
  emoji TEXT DEFAULT '',
  name TEXT NOT NULL,
  price NUMERIC(10,2) NOT NULL,
  active BOOLEAN NOT NULL DEFAULT true
);

CREATE TABLE IF NOT EXISTS card_types (
  id TEXT PRIMARY KEY,
  emoji TEXT DEFAULT '',
  label TEXT NOT NULL,
  category TEXT DEFAULT 'geral',
  active BOOLEAN NOT NULL DEFAULT true
);

CREATE TABLE IF NOT EXISTS occasions (
  id TEXT PRIMARY KEY,
  emoji TEXT DEFAULT '',
  name TEXT NOT NULL,
  tags TEXT[] NOT NULL DEFAULT '{}',
  active BOOLEAN NOT NULL DEFAULT true
);

CREATE TABLE IF NOT EXISTS customers (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  phone TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS orders (
  id SERIAL PRIMARY KEY,
  order_number TEXT UNIQUE NOT NULL,
  customer_id INTEGER REFERENCES customers(id),
  customer_name TEXT NOT NULL,
  customer_email TEXT,
  customer_phone TEXT,
  shipping_address JSONB,
  delivery_method TEXT DEFAULT 'normal',
  carrier TEXT,
  service TEXT,
  tracking_code TEXT UNIQUE,
  estimated_delivery DATE,
  payment_method TEXT,
  payment_status TEXT NOT NULL DEFAULT 'pendente',
  subtotal NUMERIC(10,2) NOT NULL DEFAULT 0,
  shipping NUMERIC(10,2) NOT NULL DEFAULT 0,
  discount NUMERIC(10,2) NOT NULL DEFAULT 0,
  total NUMERIC(10,2) NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'novo',
  gifts JSONB NOT NULL DEFAULT '[]',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
-- status possíveis: novo, pago, preparacao, montado, enviado, entregue, cancelado, reembolsado

CREATE TABLE IF NOT EXISTS order_events (
  id SERIAL PRIMARY KEY,
  order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  status TEXT NOT NULL,
  note TEXT DEFAULT '',
  created_by INTEGER REFERENCES admin_users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_order_events_order_id ON order_events(order_id);

CREATE TABLE IF NOT EXISTS order_items (
  id SERIAL PRIMARY KEY,
  order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  gift_index INTEGER NOT NULL DEFAULT 0,
  product_id TEXT REFERENCES products(id),
  product_name TEXT NOT NULL,
  quantity INTEGER NOT NULL,
  unit_price NUMERIC(10,2) NOT NULL,
  line_total NUMERIC(10,2) NOT NULL
);

CREATE TABLE IF NOT EXISTS stock_movements (
  id SERIAL PRIMARY KEY,
  product_id TEXT NOT NULL REFERENCES products(id),
  change INTEGER NOT NULL,
  reason TEXT NOT NULL,
  resulting_stock INTEGER NOT NULL,
  order_id INTEGER REFERENCES orders(id),
  created_by INTEGER REFERENCES admin_users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
CREATE INDEX IF NOT EXISTS idx_orders_created_at ON orders(created_at);
CREATE INDEX IF NOT EXISTS idx_order_items_order_id ON order_items(order_id);
CREATE INDEX IF NOT EXISTS idx_stock_movements_product_id ON stock_movements(product_id);
CREATE INDEX IF NOT EXISTS idx_orders_tracking_code ON orders(tracking_code);

-- =====================================================================
-- SEED — os mesmos dados que já existiam hardcoded no arquivo do site
-- (estoque inicial de 20 unidades por produto — ajuste depois pelo painel)
-- =====================================================================

INSERT INTO products (id,name,description,price,categories,emoji,gradient,rating,stock,min_stock) VALUES
('p1','Perfume Âmbar Noir','Fragrância amadeirada intensa, frasco de 100ml.',129.9,'{perfumes,masculino}','🧴','#EADFD3,#F1E8DA',4.8,20,3),
('p2','Eau de Parfum Flor Rose','Notas florais delicadas com toque adocicado.',139.9,'{perfumes,feminino}','🌸','#F3E1DC,#F8EDE8',4.9,20,3),
('p3','Caixa de Chocolates Belga','12 unidades sortidas, embalagem premium.',49.9,'{chocolates,casal}','🍫','#E7D9C8,#F1E8DA',4.9,20,3),
('p4','Trufas Artesanais','8 trufas recheadas, feitas à mão.',38.9,'{chocolates,gourmet}','🍬','#EFE3D3,#F6EEE1',4.7,20,3),
('p5','Ursinho de Pelúcia Grande','45cm, super macio, acabamento premium.',79.9,'{pelucias,infantil,casal}','🧸','#F1E3D6,#F8EFE3',4.8,20,3),
('p6','Ursinho Mini com Laço','18cm, ideal para compor a caixa.',34.9,'{pelucias,infantil}','🐻','#F1E3D6,#F8EFE3',4.6,20,3),
('p7','Carteira de Couro','Couro legítimo, porta-cartões interno.',99.9,'{acessorios,masculino}','👛','#E5D6C3,#EFE3D3',4.7,20,3),
('p8','Relógio Clássico','Pulseira de couro, mostrador minimalista.',249.9,'{acessorios,masculino}','⌚','#E2D3C1,#EDE0CE',4.9,20,3),
('p9','Colar Delicado Banhado a Ouro','Pingente minimalista, banho de ouro 18k.',89.9,'{acessorios,feminino}','📿','#F0E4D2,#F7EFE1',4.8,20,3),
('p10','Kit Skincare Essencial','Sérum, hidratante e água micelar.',119.9,'{beleza,feminino}','🧴','#F3E9DC,#FAF3E7',4.6,20,3),
('p11','Vela Aromática Âmbar & Baunilha','Queima de até 40h, frasco de vidro reutilizável.',44.9,'{casa,feminino,casal}','🕯️','#EDE0CC,#F5EEDD',4.7,20,3),
('p12','Xícara Personalizada com Nome','Cerâmica premium, gravação a laser.',54.9,'{personalizados,casa}','☕','#E9DCC9,#F3EADA',4.8,20,3),
('p13','Moleskine com Iniciais','Capa em couro sintético, gravação personalizada.',64.9,'{personalizados,acessorios}','📓','#E4D5C1,#EFE2CE',4.7,20,3),
('p14','Caixa Gourmet Café & Doces','Café especial, biscoitos e mel artesanal.',74.9,'{gourmet,casa}','☕','#E6D8C6,#F0E5D5',4.6,20,3),
('p15','Bolsa Estruturada Mini','Alça removível, acabamento premium.',189.9,'{acessorios,feminino}','👜','#F0E2D4,#F8EFE4',4.8,20,3),
('p16','Kit Barba Premium','Óleo, balm e pente de madeira.',94.9,'{beleza,masculino}','🪒','#E3D4C0,#EEE1CD',4.7,20,3),
('p17','Buquê de Flores Artificiais','Dura para sempre, acabamento realista.',59.9,'{casa,feminino,casal}','💐','#F1E1D9,#F9EDE7',4.6,20,3),
('p18','Chocolate Quente Gourmet','Lata de 200g, receita cremosa belga.',29.9,'{chocolates,gourmet}','🍫','#E9DBC8,#F2E7D6',4.5,20,3),
('p19','Kit Brinquedos Educativos','Quebra-cabeças e blocos de montar.',69.9,'{infantil}','🧩','#F0E5D6,#F8F0E5',4.6,20,3),
('p20','Doces Personalizados com Nome','12 unidades com embalagem temática.',39.9,'{infantil,personalizados}','🍭','#F2E4D8,#F9EEE5',4.7,20,3),
('p21','Porta-retrato Gravado','Madeira nobre com gravação a laser.',49.9,'{personalizados,casa}','🖼️','#E7D9C7,#F1E6D4',4.8,20,3),
('p22','Kit Experiência Casal','Espumante, taças e chocolates finos.',159.9,'{casal,gourmet}','🥂','#EBDDC9,#F4EBDA',4.9,20,3)
ON CONFLICT (id) DO NOTHING;

INSERT INTO packaging_boxes (id,name,price,capacity,emoji,stock,min_stock) VALUES
('essencial','Caixa Essencial',9.9,3,'📦',50,5),
('premium','Caixa Premium',19.9,5,'🎁',50,5),
('luxo','Caixa Luxo',29.9,8,'🎀',50,5),
('romantica','Caixa Romântica',34.9,5,'💝',50,5),
('personalizada','Caixa Personalizada',39.9,8,'✨',50,5)
ON CONFLICT (id) DO NOTHING;

INSERT INTO box_colors (id,hex) VALUES
('branca','#FBF9F5'),('preta','#2A2622'),('rosa','#E7B9AE'),('vermelha','#A6362B'),('bege','#E3D2B4'),('azul','#8FA9BE')
ON CONFLICT (id) DO NOTHING;

INSERT INTO ribbons (id,label,hex) VALUES
('sem-fita','Sem fita','transparent'),('branca',NULL,'#FBF9F5'),('preta',NULL,'#2A2622'),
('rosa',NULL,'#C77D6E'),('vermelha',NULL,'#A6362B'),('dourada',NULL,'#B8935F')
ON CONFLICT (id) DO NOTHING;

INSERT INTO papers (id,hex) VALUES
('branco','#FBF9F5'),('bege','#E3D2B4'),('rosa','#E7B9AE'),('preto','#2A2622'),('vermelho','#A6362B')
ON CONFLICT (id) DO NOTHING;

INSERT INTO extras (id,emoji,name,price) VALUES
('foto','📸','Foto impressa',14.9),
('carta-premium','💌','Carta premium',12.9),
('flor','🌹','Flor artificial',19.9),
('mini-pelucia','🧸','Mini pelúcia',24.9),
('chocolate-extra','🍫','Chocolate extra',16.9),
('laco','🎀','Laço personalizado',9.9),
('tag','🏷️','Tag com nome',7.9),
('qr-musica','🔗','QR Code para uma música',9.9),
('qr-video','🎥','QR Code para um vídeo',9.9),
('cartao','💖','Cartão especial',11.9)
ON CONFLICT (id) DO NOTHING;

INSERT INTO card_types (id,emoji,label) VALUES
('amor','❤️','Para meu amor'),('pedido-casamento','💍','Pedido de casamento'),
('casamento','💒','Casamento'),('aniversario','🎂','Aniversário'),
('mae','👩','Para minha mãe'),('pai','👨','Para meu pai'),
('amigo','🤝','Para um amigo'),('agradecimento','🙏','Agradecimento'),
('especial','🥰','Mensagem especial'),('propria','✍️','Escrever minha própria mensagem')
ON CONFLICT (id) DO NOTHING;

INSERT INTO occasions (id,emoji,name,tags) VALUES
('namoro','❤️','Namoro','{chocolates,perfumes,pelucias,personalizados}'),
('aniversario','🎂','Aniversário','{chocolates,beleza,acessorios,gourmet}'),
('pedido-namoro','🌹','Pedido de namoro','{perfumes,chocolates,personalizados}'),
('pedido-casamento','💍','Pedido de casamento','{acessorios,personalizados,beleza}'),
('casamento','💒','Casamento','{casa,acessorios,gourmet}'),
('noivado','💞','Noivado','{acessorios,perfumes,personalizados}'),
('dia-namorados','💘','Dia dos Namorados','{chocolates,perfumes,pelucias}'),
('dia-maes','👩','Dia das Mães','{beleza,perfumes,casa}'),
('dia-pais','👨','Dia dos Pais','{acessorios,gourmet,perfumes}'),
('amizade','🤝','Amizade','{chocolates,gourmet,personalizados}'),
('formatura','🎓','Formatura','{acessorios,gourmet,personalizados}'),
('agradecimento','🙏','Agradecimento','{chocolates,gourmet,casa}'),
('desculpas','🕊️','Desculpas','{chocolates,perfumes,pelucias}'),
('boa-sorte','🍀','Boa sorte','{gourmet,personalizados,acessorios}'),
('parabens','🎉','Parabéns','{chocolates,gourmet,beleza}'),
('natal','🎄','Natal','{gourmet,casa,perfumes}'),
('sem-motivo','✨','Sem motivo especial','{chocolates,beleza,personalizados}')
ON CONFLICT (id) DO NOTHING;
