// Aplica o schema.sql (estrutura das tabelas + seed inicial) no banco configurado em DATABASE_URL.
// Uso: npm run migrate
require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { Pool } = require('pg');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DATABASE_SSL === 'true' ? { rejectUnauthorized: false } : false,
});

async function main() {
  const sql = fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8');
  console.log('Aplicando schema.sql no banco...');
  await pool.query(sql);
  console.log('Pronto! Tabelas criadas/atualizadas e dados iniciais inseridos.');
  await pool.end();
}

main().catch((err) => {
  console.error('Erro ao aplicar o schema:', err);
  process.exit(1);
});
